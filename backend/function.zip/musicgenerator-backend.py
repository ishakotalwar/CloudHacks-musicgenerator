import json
import requests
import base64
import os
import requests

ALPHA_PATTERN = re.compile(r"^[A-Za-z ]+$")

def lambda_handler(event, context):
    try:
        # Parse mood from request body
        body = json.loads(event['body'] or "{}")
        mood = body.get('mood')
        if not isinstance(mood, str) or not mood.strip(): #if the user does not input a valid string
            return {
                "statusCode": 400,
                "headers": {"Access-Control-Allow-Origin": "*"},
                "body": json.dumps({
                    "error": "Please provide a non-empty 'mood' string, e.g. { \"mood\": \"chill\" }"
                })
            }
        mood = mood.strip().lower()

        # Spotify credentials from environment variables
        client_id = os.environ['SPOTIFY_CLIENT_ID']
        client_secret = os.environ['SPOTIFY_CLIENT_SECRET']

        # Encode credentials
        auth_str = f"{client_id}:{client_secret}"
        b64_auth = base64.b64encode(auth_str.encode()).decode()

        # Get access token from Spotify
        token_res = requests.post(
            "https://accounts.spotify.com/api/token",
            data={"grant_type": "client_credentials"},
            headers={"Authorization": f"Basic {b64_auth}"}
        )

        token = token_res.json().get("access_token")

        if not token:
            return {"statusCode": 500, "body": json.dumps({"error": "Spotify auth failed"})}

        # Search Spotify for tracks matching the mood
        search_url = f"https://api.spotify.com/v1/search?q={mood}&type=track&limit=5"
        res = requests.get(
            search_url,
            headers={"Authorization": f"Bearer {token}"}
        )

        items = res.json().get("tracks", {}).get("items", [])

        songs = []
        for t in items:
            songs.append({
                "name": t["name"],
                "artist": t["artists"][0]["name"],
                "url": t["external_urls"]["spotify"]
            })

        return {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({"songs": songs})
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
